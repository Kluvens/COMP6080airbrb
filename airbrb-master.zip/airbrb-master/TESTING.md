The second path in ui testing is to Is to check whether the user is correctly logged in and registered
1. Login to a page the user have not registered with
2. Register successful
3. Register with empty username
4. Mutiple registation casue error