describe('Happy path for a hoster', () => {
  it('Resigters a account successfully ', () => {
    cy.visit('localhost:3000/register');
    const name = 'Mike';
    const email = 'Mik6@gail.com';
    const password = 'Mikee66';
    const conPassword = 'Mikee66';
    cy.get('input[name=name]')
      .focus()
      .type(name)
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)
    cy.get('input[name=confirmPassword]')
      .focus()
      .type(conPassword)
    cy.contains('Submit')
      .click();
  });

  beforeEach(() => {
    cy.visit('localhost:3000/login');
    const email = 'Mik6@gmail.com';
    const password = 'Mikee66';
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)

    cy.contains('Submit')
      .click();
  });

  it('Successfully create a new listing ', () => {
    cy.visit('localhost:3000/listings/new');
    const title = 'The best home near UNSW in syd';
    const street = '70 Anzac pde';
    const suburb = 'kingsford';
    const state = 'NSW';
    const price = '500';
    const bathrooms = '3';
    const bedrooms = '3';
    const beds = '3';

    cy.get('input[name=title]')
      .focus()
      .type(title)
    cy.get('input[name=street]')
      .focus()
      .type(street)
    cy.get('input[name=suburb]')
      .focus()
      .type(suburb)
    cy.get('input[name=state]')
      .focus()
      .type(state)
    cy.get('input[name=price_per_night]')
      .focus()
      .type(price)
    cy.get('[name=property_type]').parent().click();

    cy.contains('House').click();
    cy.get('input[name=thumbnail_upload]')
      .selectFile('cypress/e2e/house.jpg', { force: true })
    cy.get('input[name=bathrooms]')
      .focus()
      .type(bathrooms, { force: true })
    cy.get('input[name=bedrooms]')
      .focus()
      .type(bedrooms, { force: true })
    cy.get('input[name=beds]')
      .focus()
      .type(beds, { force: true })
    cy.get('input[name=air_conditioning]')
      .check({ force: true });
    cy.get('input[name=heater]')
      .check({ force: true });

    cy.get('.justify-end').find('button').click();
  });

  it('Update the thumbnail and the title', () => {
    cy.visit('localhost:3000/hosted');
    cy.contains('Edit').click()
    cy.contains('Title').siblings('.underline.cursor-pointer').click();
    const newTitle = 'A Nice house near UNSW ';
    cy.contains('Edit')
      .click()
    cy.get('input[name=title]')
      .clear()
      .type(newTitle)
    cy.contains('Temp save').click();

    cy.contains('Thumbnail').siblings('.underline.cursor-pointer').click();
    cy.get('input[name=thumbnail]')
      .selectFile('cypress/e2e/house2.jpg', { force: true })
    cy.contains('Temp save').click();
    cy.contains('Save changes')
      .click();
  })

  it('Publish a listing', () => {
    cy.visit('localhost:3000/hosted');
    cy.contains('button', 'Go live').click();
    cy.url().should('include', '/publish/');
    cy.contains('Save').click();
    cy.contains('Submit').click();
  })

  it('Unpublish a listing', () => {
    cy.visit('localhost:3000/hosted');
    cy.contains('Unpublish')
      .click()
  })

  it('Successfully view the bookings', () => {
    cy.visit('localhost:3000/listings/');
    cy.contains('Submit')
      .click()
  })

  it('Successfully logs out', () => {
    cy.visit('localhost:3000/');
    cy.get('[data-testid="dropdown-trigger"]')
      .click();
    cy.contains('Logout')
      .click();
    cy.url().should('eq', 'http://localhost:3000/');
  });
});