describe('Unhappy path', () => {
// the account is not exist
  it('Login in with an unexist email', () => {
    cy.visit('localhost:3000/login');
    const email = 'Anna66@gmail.com';
    const password = 'Anna66';
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)
    cy.contains('Submit')
      .click();
    cy.wait(1000)
  });

//  Register successful
  it ('Successfully signs up', () => {
    cy.visit('localhost:3000/register');
    const name = 'Anna';
    const email = 'Anna66@gmail.com';
    const password = 'Anna';
    const conPassword = 'Anna';
    cy.get('input[name=name]')
      .focus()
      .type(name)
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)
    cy.get('input[name=confirmPassword]')
      .focus()
      .type(conPassword)
    cy.contains('Submit')
      .click();
  });
// Regist without username
  it ('Empty User name', () => {
    cy.visit('localhost:3000/register');
    const email = 'Anna66@gmail.com';
    const password = 'Anna';
    const conPassword = 'Anna';
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)
    cy.get('input[name=confirmPassword]')
      .focus()
      .type(conPassword)
    cy.contains('Submit')
      .click();
    cy.wait(1000)
  });

  it ('Signs up again', () => {
    cy.visit('localhost:3000/register');
    const name = 'Anna';
    const email = 'Anna66@gmail.com';
    const password = 'Anna';
    const conPassword = 'Anna';
    cy.get('input[name=name]')
      .focus()
      .type(name)
    cy.get('input[name=email]')
      .focus()
      .type(email)
    cy.get('input[name=password]')
      .focus()
      .type(password)
    cy.get('input[name=confirmPassword]')
      .focus()
      .type(conPassword)
    cy.contains('Submit')
      .click();
  });
});