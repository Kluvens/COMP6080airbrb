import React from 'react';
import { Flex } from '@radix-ui/themes';
import Listing from './Listing/Listing';

const Listings = (props) => {
  const { listings, dateRange } = props;
  return (
    <Flex className='grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8'>
      {listings.map((listing) => (
        <Listing
          key={listing.id}
          id={listing.id}
          owner={listing.owner}
          title={listing.title}
          price={listing.price}
          thumbnail={listing.thumbnail}
          reviews={listing.reviews}
          dateRange={dateRange}
        />
      ))}
    </Flex>
  )
}

export default Listings;
