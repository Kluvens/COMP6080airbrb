import { Flex, Text } from '@radix-ui/themes';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChatBubbleIcon } from '@radix-ui/react-icons';

const Listing = (props) => {
  const navigate = useNavigate();
  const {
    id,
    title,
    price,
    thumbnail,
    reviews,
    dateRange,
  } = props;

  const handleClick = (listingId) => {
    const queryString = dateRange.startDate && dateRange.endDate
      ? `?startDate=${dateRange.startDate}&endDate=${dateRange.endDate}`
      : '';
    navigate('/listings/' + listingId + queryString);
  }

  return (
    <Flex onClick={() => handleClick(id)} className='flex-col group cursor-pointer'>
      <Flex className='mt-5 aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-lg bg-gray-200 xl:aspect-h-8 xl:aspect-w-7'>
        <img
          src={thumbnail}
          alt={`${title} iamge`}
          className='h-full w-full object-cover object-center group-hover:opacity-75'
        />
      </Flex>
      <Text as='p' className='mt-4 text-lg font-bold text-gray-700'>{title}</Text>
      <Text as='p' className='mt-1 text-base text-gray-900 underline'><Text className='font-bold'>${price} </Text>per night</Text>
      <Text as='p' className='flex items-center'><ChatBubbleIcon className='mr-1' />{reviews.length} reviews</Text>
    </Flex>
  )
}

export default Listing;
