import { Button } from '@radix-ui/themes';
import React from 'react';

const ButtonTesting = () => {
  return (
    <Button>Testing</Button>
  )
}

export default ButtonTesting;
