import React from 'react';
import { Flex, Text } from '@radix-ui/themes';
import AuthDropdown from '../AuthDropdown/AuthDropdown';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/');
  }

  return (
    <Flex className='items-center justify-between py-4 sticky top-0 bg-white/30 backdrop-blur-lg z-50'>
      <Text onClick={handleClick} className='ui-monospace tracking-wide text-violet-900 text-xl font-bold mt-2 cursor-pointer'>Airbrb</Text>
      <AuthDropdown />
    </Flex>
  )
}

export default Navbar;
