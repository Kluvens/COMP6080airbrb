import React from 'react';
import {
  useNavigate,
} from 'react-router-dom';
import { apiCall } from '../../utils/Helper';
import * as Form from '@radix-ui/react-form';
import { Button, Flex } from '@radix-ui/themes';
import { PersonIcon, EnvelopeClosedIcon, LockClosedIcon, EyeClosedIcon, EyeOpenIcon } from '@radix-ui/react-icons'

// Register a user
const Register = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  // Can show the password
  const passwordVisibility = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setShowPassword(!showPassword);
  };
  // Can show the confirm password
  const confirmPasswordVisibility = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setShowConfirmPassword(!showConfirmPassword);
  };
  // Submit the form
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = Object.fromEntries(new FormData(event.currentTarget));
    const { email, name, password, confirmPassword } = formData;
    // Check the input validation
    if (!name.trim() && !password.trim()) {
      alert('Name and password cannot be spaces.');
      return;
    } else if (!name.trim()) {
      alert('Name cannot be spaces.');
      return;
    } else if (!password.trim()) {
      alert('Password cannot be spaces.');
      return;
    }
    if (password !== confirmPassword) {
      alert('Passwords does not match!');
      return;
    }
    // Get register API
    const data = await apiCall('/user/auth/register', 'POST', { email, password, name }, null);
    if (data) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('email', email);
      navigate('/');
    } else {
      console.log('failed');
    }
  }

  return (
    <Flex className='min-h-[700px] justify-center items-center'>
      <Form.Root className='w-96 mx-auto' onSubmit={handleSubmit}>
        {/* Name */}
        <Form.Field className='grid mb-3' name='name'>
          <Flex className='items-baseline justify-between'>
            <Form.Label className='text-purple-500 form-label flex flex-row'><PersonIcon className='mt-2 mr-3'/>  Name</Form.Label>
            <Form.Message className= 'font-small' match='valueMissing'>Please enter your name</Form.Message>
          </Flex>
          <Form.Control name='name' className='form-input w-full pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400'
            type='text' required placeholder='Enter your name here' />
        </Form.Field>
        {/* Email */}
        <Form.Field className='grid mb-3' name='email'>
          <Flex className='items-baseline justify-between'>
            <Form.Label className='text-purple-500 form-label flex flex-row'><EnvelopeClosedIcon className='mt-2 mr-3'/>  Email</Form.Label>
            <Form.Message className= 'font-small' match='valueMissing'>Please enter an email</Form.Message>
            <Form.Message className= 'font-small' match='typeMismatch'>Please provide a vaild email</Form.Message>
          </Flex>
          <Form.Control className='form-input w-full pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400'
            type='email' required placeholder='Enter your email here' />
        </Form.Field>
        {/* Password */}
        <Form.Field className='grid mb-3' name='password'>
          <Flex className=' items-baseline justify-between'>
            <Form.Label className='text-purple-500 form-label flex flex-row'> <LockClosedIcon className='mt-2 mr-3' />  Password</Form.Label>
            <Form.Message className= 'font-small' match='valueMissing'>Please enter a password</Form.Message>
          </Flex>
          <Flex className='relative'>
            <Form.Control className='form-input w-72 pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400'
              type={showPassword ? 'text' : 'password'} required placeholder='Enter your password here' />
            <Button onClick={(event) => passwordVisibility(event)} className='icon-input mt-2'>
              {showPassword ? <EyeClosedIcon /> : <EyeOpenIcon />}
            </Button>
          </Flex>
        </Form.Field>
        {/* Confirm password */}
        <Form.Field className='grid mb-3 relative' name='confirmPassword'>
          <Flex className='items-baseline justify-between'>
            <Form.Label className='text-purple-500 form-label flex flex-row'><LockClosedIcon className='mt-2 mr-3' /> Confirm Password</Form.Label>
            <Form.Message className= 'font-small' match='valueMissing'>Please enter a password</Form.Message>
          </Flex>
          <Flex className='relative'>
            <Form.Control className='form-input w-72 pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400'
              name = 'confirmPassword' type={showConfirmPassword ? 'text' : 'password'} required placeholder='Re-enter your password' />
            <Button onClick={(event) => confirmPasswordVisibility(event)} className='icon-input mt-2'>
              {showConfirmPassword ? <EyeClosedIcon /> : <EyeOpenIcon />}
            </Button>
          </Flex>
        {/* Submit Button */}
        </Form.Field>
          <Form.Submit asChild>
            <Flex className='justify-center'>
              <Button className='cursor-pointer text-white font-bold shadow-md hover:scale-[1.2] shadow-purple-400 rounded-full w-1/2 mt-2 px-5 py-2 bg-gradient-to-bl from-purple-500 to-purple-800' type="submit" name='submit'>Submit</Button>
          </Flex>
          </Form.Submit>
      </Form.Root>
    </Flex>

  )
};

export default Register;
