import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Flex } from '@radix-ui/themes';
import { apiCall } from '../../utils/Helper';
import HostedListing from './HostedListing/HostedListing';
// Detect any update in the particular listing and response in host listings screen
const HostedListings = () => {
  const [listings, setListings] = useState([]);
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const navigate = useNavigate();
  useEffect(() => {
    if (!token || !email) {
      navigate('/login');
    }
    const fetchData = async () => {
      try {
        const hostedListingData = await apiCall('/listings', 'GET', null, null);
        if (hostedListingData) {
          const hostedListings = [...hostedListingData.listings]
            .filter(listing => listing.owner === email)
            .map(async (listing) => {
              const metadataResponse = await apiCall('/listings/' + listing.id, 'GET', null, token);
              return { ...listing, ...metadataResponse.listing.metadata, published: metadataResponse.listing.published };
            })
          const listingsWithDetails = await Promise.all(hostedListings);
          const sortedHostedListings = [...listingsWithDetails].sort((a, b) => a.title.localeCompare(b.title));
          setListings(sortedHostedListings);
        } else {
          console.log('failed');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  return (
    <Flex className={'grid grid-cols-1 gap-x-6 gap-y-10 mt-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8'}>
      {listings.map((listing, idx) => {
        return (
        <HostedListing
          key={listing.id}
          token={token}
          id={listing.id}
          owner={listing.owner}
          title={listing.title}
          price={listing.price}
          bathrooms={listing.num_bathrooms}
          beds={listing.num_beds}
          type={listing.property_type}
          thumbnail={listing.thumbnail}
          rating={listing.reviews.reduce((sum, review) => sum + parseInt(review.rating), 0) / listing.reviews.length || 0.0}
          reviews={listing.reviews || []}
          published={listing.published}
        />
        );
      })}
    </Flex>
  )
}

export default HostedListings;
