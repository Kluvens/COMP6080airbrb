import { Flex, Text, Button } from '@radix-ui/themes';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiCall } from '../../../utils/Helper';
import { ChatBubbleIcon, StarFilledIcon } from '@radix-ui/react-icons';

const HostedListing = (props) => {
  const navigate = useNavigate();
  const {
    token,
    id,
    title,
    price,
    beds,
    type,
    bathrooms,
    thumbnail,
    rating,
    reviews,
    published,
  } = props;
  const [isPublished, setIsPublished] = useState(published);

  const handleClick = (listingId) => {
    navigate('/hosted/' + listingId);
  }
  const handleEditClick = (listingId) => {
    navigate('/listings/edit/' + listingId);
  }
  const handlePublishClick = (listingId) => {
    navigate('/publish/' + listingId);
  }
  // Call unpublish API
  const handleUnpublishClick = async (listingId) => {
    const response = await apiCall('/listings/unpublish/' + listingId, 'PUT', {}, token);
    if (response) {
      setIsPublished(!published)
    }
  }
  // Delete the particular listing, call /listings/{listingid}
  const handleDeleteClick = async (listingId) => {
    try {
      const data = await apiCall('/listings/' + listingId, 'DELETE', null, token);
      if (data) {
        alert('Delete success!');
        window.location.reload();
      }
    } catch (error) {
      console.error('Error:', error);
      alert(Error);
    }
  }
  return (
    <Flex direction='column'>
      <Flex onClick={() => handleClick(id)} direction='column' className='group cursor-pointer'>
        {/* Thumbnail of the listing */}
        <Flex className='mt-2 aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-lg bg-gray-200 xl:aspect-h-8 xl:aspect-w-7'>
          <img src={thumbnail} alt='hosted image' className='group-hover:opacity-75 z-0'/>
        </Flex>
        <Flex className='justify-between'>
          {/* Show the title and rating */}
          <Flex className='flex-col w-full'>
            <Flex className='mt-2 text-xl font-medium justify-between'>
              <Flex>
                {title}
              </Flex>
              <Flex className='items-center'>
                <StarFilledIcon className='mr-1' />{rating.toFixed(2)}
              </Flex>
            </Flex>
            {/* Price */}
            <Text as='p' className='mt-1 text-base text-gray-900 underline'><Text className='font-bold'>${price} </Text>per night</Text>
            {/* Property type */}
            <Text as='p' className='mt-1 text-sm text-gray-700'>{type}</Text>
            {/* Bathrooms, beds */}
            <Text as='p' className='mt-1 text-sm text-gray-700'>{beds} beds · {bathrooms} bathrooms </Text>
            {/* Number of total reviews */}
            <Text as='p' className='flex items-center'><ChatBubbleIcon className='mr-1'/>{reviews.length} reviews</Text>
          </Flex>
        </Flex>
      </Flex>
      {/* Can click to publish/edit/delect/unpublish this listing */}
      <Flex className='grid grid-cols-3 gap-x-6 mt-1'>
          {!isPublished
            ? <Button className='cursor-pointer' onClick={() => handlePublishClick(id)}>Go live</Button>
            : <Button className='cursor-pointer' onClick={() => handleUnpublishClick(id)}>Unpublish</Button>
          }
          <Button className='cursor-pointer' onClick={() => handleEditClick(id)}>Edit</Button>
          <Button className='cursor-pointer' variant='solid' color='red' onClick={() => handleDeleteClick(id)}>Delete</Button>
        </Flex>
    </Flex>
  )
}

export default HostedListing;
