import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { apiCall } from '../../utils/Helper';
import { Flex, Heading, Separator, Text, Button, TextField, Avatar } from '@radix-ui/themes';
import { HomeIcon, ChatBubbleIcon, StarFilledIcon } from '@radix-ui/react-icons'
import AcUnitIcon from '@mui/icons-material/AcUnit';
import FireplaceIcon from '@mui/icons-material/Fireplace';
import Datepicker from 'react-tailwindcss-datepicker';
import 'daisyui';
import { Label } from '@radix-ui/react-label';
import LocationOnIcon from '@mui/icons-material/LocationOn';

// Show the particular listing details
const ListingDetails = () => {
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const { listingId } = useParams();
  const [listingDetails, setListingDetails] = useState({});
  const [images, setPropertyImages] = useState([]);
  const [booking, setBooking] = useState({});
  const [reviews, setReviews] = useState([]);
  const [allBookings, setAllBookings] = useState([]);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const startRangeDate = searchParams.get('startDate');
  const endRangeDate = searchParams.get('endDate');
  const [value, setValue] = useState(() => {
    const start = new Date();
    const end = new Date();
    end.setDate(start.getDate() + 1);
    return {
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
    };
  });

  useEffect(() => {
    // Get the listing details by call get particular list API
    const fetchListingDetails = async () => {
      try {
        const response = await apiCall('/listings/' + listingId, 'GET', null, token || null);
        if (response) {
          setListingDetails(response.listing);
          // get list of property images
          const imagesListing = response.listing.thumbnail ? [response.listing.thumbnail, ...(response.listing.metadata.images || [])] : [...(response.listing.metadata.images || [])];
          setPropertyImages(imagesListing);
          setReviews(response.listing.reviews);
        } else {
          console.log('Failed!');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchListingDetails();
    // Only the login user can booking and booked user can write the review(status is accepted)
    if (token && email) {
      const fetchBooking = async () => {
        const response = await apiCall('/bookings', 'GET', null, token);
        if (response) {
          const filteredBookings = response.bookings.filter((booking) => booking.owner === email && booking.listingId === listingId && booking.status === 'accepted');
          setBooking(filteredBookings[filteredBookings.length - 1]);
        }
      }
      fetchBooking();
    }
    // Show all booking request
    if (token && email) {
      const fetchAllBookingsRequest = async () => {
        const response = await apiCall('/bookings', 'GET', null, token);
        if (response) {
          const userBookings = response.bookings.filter(booking => booking.owner === email && booking.listingId === listingId);
          setAllBookings(userBookings);
        }
      }
      fetchAllBookingsRequest();
    }
  }, [token, email, listingId]);
  // Check the dateRange is change or not
  const handleValueChange = (newValue) => {
    setValue(newValue);
  }
  // Booking submit, call /bookings/new/{listingid} API
  const handleBookingSubmission = async () => {
    const data = await apiCall('/bookings/new/' + listingId, 'POST', {
      dateRange: value,
      totalPrice: parseFloat(listingDetails.price) * ((new Date(value.endDate) - new Date(value.startDate)) / (1000 * 60 * 60 * 24)).toString(),
    }, token);
    if (data) {
      alert('Booking request send!');
    }
  }
  // Calcuate the total price from the date range search bar
  const totalPriceCalculate = () => {
    if (startRangeDate && endRangeDate) {
      const totalDays = (new Date(endRangeDate) - new Date(startRangeDate)) / (1000 * 60 * 60 * 24);
      return parseFloat(listingDetails.price) * totalDays;
    }
    return listingDetails.price;
  };
  // Calcuate the average rating about review
  const calculateAverageRating = () => {
    if (reviews.length === 0) return 0;
    const totalRating = reviews.reduce((acc, review) => acc + Number(review.rating), 0);
    return totalRating / reviews.length;
  }
  // Submit the comment after booking is accepted
  const handleSubmitComment = async (e) => {
    const formData = Object.fromEntries(new FormData(e.currentTarget));
    const rating = formData.rating;
    const comment = formData.comment;
    const response = await apiCall('/listings/' + listingId + '/review/' + booking.id, 'PUT', {
      review: {
        rating,
        comment,
      }
    }, token);
    if (response) {
      const response = await apiCall('/listings/' + listingId, 'GET', null, token);
      if (response) {
        setListingDetails(response.listing);
        const imagesListing = response.listing.thumbnail ? [response.listing.thumbnail, ...(response.listing.metadata.images || [])] : [...(response.listing.metadata.images || [])];
        setPropertyImages(imagesListing);
        setReviews(response.listing.reviews);
        alert('Review submitted successfully');
      }
    } else {
      alert('comment failed to send, please enter a valid review or check booking status');
    }
  }

  const airConditioningStatusOn = listingDetails.metadata?.amenities?.air_conditioning === 'on';
  const heaterStatusOn = listingDetails.metadata?.amenities?.heater === 'on';

  return (
    <Flex direction='column'>
      <Separator orientation='horizontal' size='auto' />
      <Flex className='flex flex-row place-content-between items-center'>
        <Heading className=' mt-5 text:xl lg:text-3xl font-semibold ui-monospace'>{listingDetails.title}</Heading>
        <Text className=' mt-6 text-base lg:text-2xl flex flex-row text-gray-500 ui-monospace items-center'><HomeIcon className='mr-2 w-6 h-6'/> {listingDetails.metadata?.property_type} </Text>
      </Flex>
      {/* Show property list */}
      <Text className=' mt-5'>
        <Flex className='carousel my-4 space-x-4 rounded-lg'>
          {images.map((imgSrc, index) => (
            <Flex key={index} className='carousel-item'>
              <img src={imgSrc} alt={`Slide ${index}`} className='h-96 object-cover rounded-lg' />
            </Flex>
          ))}
        </Flex>
      </Text>
      {/* Show address */}
      <Flex className='items_center'>
        <LocationOnIcon className='-ml-1 -mt-1'/><Text className=' mt-5text-xl text-gray-500'> {listingDetails.address?.street}, {listingDetails.address?.suburb}, {listingDetails.address?.state} </Text>
      </Flex>
      {/* Show bedrooms, beds, bathrooms number */}
      <Text className=' mt-1 text-sm'> {listingDetails.metadata?.num_bedrooms} bedroom(s) · {listingDetails.metadata?.num_beds} bed(s) · {listingDetails.metadata?.num_bathrooms} bath(s) </Text>
      <Separator className='mt-2' orientation='horizontal' size='auto' />
      {/* Show the amenities */}
      <Flex direction='column'>
        <Text className=' mt-3 font-semibold'> What this place offers</Text>
        <Text className={`flex py-2 ${airConditioningStatusOn ? '' : 'line-through'}`}>
          <AcUnitIcon className='mr-2'/>Air Conditioning
        </Text>
        <Text className={`flex py-2 ${heaterStatusOn ? '' : 'line-through'}`}>
          <FireplaceIcon className='mr-2'/>Heater
        </Text>
      </Flex>
      <Separator className='mt-2' orientation='horizontal' size='auto'/>
      {/* Booking date */}
      <Flex direction='column'>
        <Flex className='flex-row justify-between items-center'>
          <Text className=' mt-3 font-semibold'> Select checkout date</Text>
          <Text className='mt-3 font-semibold text-gray-500'>
              {startRangeDate && endRangeDate
                ? <Text>Total Price for Stay ${totalPriceCalculate()}</Text>
                : <Text>Price Per Night ${listingDetails.price}</Text>}
          </Text>
        </Flex>
        <Flex direction='column' className='my-4'>
          <Datepicker
            value={value}
            onChange={handleValueChange}
            />
          <Button onClick={handleBookingSubmission} className='mt-2'>Submit</Button>
        </Flex>
      </Flex>
      {/* All booking history with status */}
      <Flex direction='column' className='mt-4'>
        <Heading className='text-lg font-semibold'>Your Booking History :</Heading>
          {allBookings.length > 0
            ? (
                allBookings.map((booking, idx) => (
              <Flex key={idx} className='border-2 p-4 my-2 rounded-md justify-between items-center'>
                <Text>Start Date: {new Date(booking.dateRange.startDate).toLocaleDateString()}</Text>
                <Text>End Date: {new Date(booking.dateRange.endDate).toLocaleDateString()}</Text>
                <Text className={booking.status === 'accepted'
                  ? 'text-red-600'
                  : booking.status === 'pending' ? 'text-blue-700' : 'text-orange-400'}>
                  {booking.status}</Text>
              </Flex>
                ))
              )
            : (
            <Text>You have not made any bookings for this listing.</Text>
              )}
      </Flex>

      <Separator orientation='horizontal' size='auto'/>
      {/* Reviews */}
      <Flex direction='column' className='rounded-lg my-4'>
        <form onSubmit={handleSubmitComment} className='border-2 p-4 rounded-lg'>
          <Flex direction='column'>
            <Text className='text-lg font-medium my-4'>Leave your review here</Text>
            <Flex>
              <Label htmlFor='rating' className='text-base font-medium items-center mr-4'>Rating score</Label>
              <TextField.Input id='rating' name='rating' type='number' step='1' min='1' max='5' className='input-field' />
            </Flex>
            <Flex direction='column'>
              <Label htmlFor='comment' className='text-base font-medium my-2'>Leave your comment</Label>
              <TextField.Input id='comment' name='comment' className='input-field' />
            </Flex>
            <Flex className='items-center justify-end my-4'>
              <Button className='cursor-pointer'>Submit Review</Button>
            </Flex>
          </Flex>
        </form>
      </Flex>
      {/* Review rating */}
      <Flex direction='column'>
        <Flex className='justify-between items-center'>
          <Flex className='items-center text-xl mt-6 mb-2 font-medium'><ChatBubbleIcon className='mr-2'/><Text>Reviews</Text></Flex>
          <Flex className='items-center'>
            <StarFilledIcon className='mr-1 mt-5' /><Text className='mt-5'>Review Rating {calculateAverageRating().toFixed(1)}</Text>
          </Flex>
        </Flex>
        {reviews.length === 0
          ? <Text>No reviews yet</Text>
          : (reviews.map((review, idx) => (
              <Flex key={idx} className='border-2 p-4 my-2 rounded-md'>
                <Flex className='mr-4'>
                  <Avatar
                    src='https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?&w=256&h=256&q=70&crop=focalpoint&fp-x=0.5&fp-y=0.3&fp-z=1&fit=crop'
                    fallback='A'
                  />
                </Flex>
                <Flex direction='column'>
                  <Text className='flex items-center'><StarFilledIcon className='mr-1'/>{review.rating}</Text>
                  <Text>{review.comment}</Text>
                </Flex>
              </Flex>
            )))
        }
      </Flex>
    </Flex>
  )
}

export default ListingDetails;
