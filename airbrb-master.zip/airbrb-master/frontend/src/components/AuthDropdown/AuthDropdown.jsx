import React, { useState } from 'react';
import { DropdownMenu, Button, Avatar, Text } from '@radix-ui/themes';
import { HamburgerMenuIcon } from '@radix-ui/react-icons';
import { apiCall } from '../../utils/Helper';
import { useNavigate } from 'react-router-dom';

const AuthDropdown = () => {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [email, setEmail] = useState(localStorage.getItem('email') || '');
  const navigate = useNavigate();

  const handleLogout = async (event) => {
    event.preventDefault();
    const data = await apiCall('/user/auth/logout', 'POST', { email }, token);
    if (data) {
      localStorage.removeItem('token');
      localStorage.removeItem('email');
      setToken('');
      setEmail('');
      navigate('/');
    } else {
      console.log('failed');
    }
  }

  const handleLogin = (event) => {
    event.preventDefault();
    navigate('/login');
  }

  const handleRegister = (event) => {
    event.preventDefault();
    navigate('/register');
  }

  const handleAllClick = () => {
    navigate('/');
  }

  const handleHostedClick = () => {
    navigate('/hosted');
  }
  // On all screens show logout button, all listings and hosted listings when user is logged in
  return (
    <DropdownMenu.Root>
      <DropdownMenu.Trigger data-testid='dropdown-trigger'>
        <Button size='3' variant='soft' radius='full' className='cursor-pointer relative bg-light-purple'>
          <HamburgerMenuIcon />
          <Avatar
            src='https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?&w=256&h=256&q=70&crop=focalpoint&fp-x=0.5&fp-y=0.3&fp-z=1&fit=crop'
            fallback='A'
          />
        </Button>
      </DropdownMenu.Trigger>
      {token !== ''
        ? <DropdownMenu.Content align='start' className='absolute w-40 h-auto p-0 mt-1' >
            <DropdownMenu.Item className='cursor-pointer' onClick={handleAllClick}>All listings</DropdownMenu.Item>
            <DropdownMenu.Item className='cursor-pointer' onClick={handleHostedClick}>My hosted</DropdownMenu.Item>
            <DropdownMenu.Separator />
            <DropdownMenu.Item className='cursor-pointer' onClick={handleLogout}><Text color='red'>Logout</Text></DropdownMenu.Item>
          </DropdownMenu.Content>
        : <DropdownMenu.Content avoidCollisions='true' className='absolute w-40 h-auto p-0 mt-1' >
            <DropdownMenu.Item className='cursor-pointer' onClick={handleLogin}>Login</DropdownMenu.Item>
            <DropdownMenu.Item className='cursor-pointer' onClick={handleRegister}>Register</DropdownMenu.Item>
          </DropdownMenu.Content>
      }
    </DropdownMenu.Root>
  )
}

export default AuthDropdown;
