import React, { useState, useEffect } from 'react';
import { TextField, IconButton, Flex, Select, Text } from '@radix-ui/themes';
import { MagnifyingGlassIcon, MixerHorizontalIcon } from '@radix-ui/react-icons';
import Datepicker from 'react-tailwindcss-datepicker';

const SearchBar = ({ onSearch }) => {
  const [expand, setExpand] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [value, setValue] = useState(() => {
    const start = new Date();
    const end = new Date();
    end.setDate(start.getDate() + 1);
    return {
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
    };
  });
  const [bedroomsRange, setBedroomsRange] = useState({
    min: 0,
    max: 15,
  });
  const [priceRange, setPriceRange] = useState({
    min: 0,
    max: 2000,
  });
  const [orderby, setOrderby] = useState('default');

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleValueChange = (newValue) => {
    if (!newValue.startDate) {
      const newDate = {}
      const today = new Date();
      const nextday = new Date();
      nextday.setDate(today.getDate() + 1);
      newDate.startDate = today.toISOString().split('T')[0];
      newDate.endDate = nextday.toISOString().split('T')[0];
      setValue(newDate);
    } else {
      setValue(newValue);
    }
  }

  useEffect(() => {
    handleValueChange(value);
  }, [value]);

  const handleMinRoomsChange = (event) => {
    const value = event.target.value;
    setBedroomsRange((prevRange) => ({
      ...prevRange,
      min: value === '' ? '' : parseInt(value) || 0,
    }));
  };

  const handleMaxRoomsChange = (event) => {
    const value = event.target.value;
    setBedroomsRange((prevRange) => ({
      ...prevRange,
      max: value === '' ? '' : parseInt(value) || 0,
    }));
  };

  const handleMinPriceChange = (event) => {
    const value = event.target.value;
    setPriceRange((prevRange) => ({
      ...prevRange,
      min: value === '' ? '' : parseFloat(value) || 0,
    }));
  };

  const handleMaxPriceChange = (event) => {
    const value = event.target.value;
    setPriceRange((prevRange) => ({
      ...prevRange,
      max: value === '' ? '' : parseFloat(value) || 0,
    }));
  };

  const handleOrderbyChange = (value) => {
    setOrderby(value);
  };

  const handleSearch = () => {
    onSearch(inputValue, bedroomsRange, value, priceRange, orderby);
  }

  return (
    <Flex direction='column' className='mt-4'>
      <TextField.Root className='flex items-center h-12 w-full'>
        <TextField.Input
          type='text'
          radius='full'
          placeholder='Search the docs…'
          onChange={handleInputChange}
          className='input-field'
        />
        <TextField.Slot>
          <MixerHorizontalIcon
            onClick={() => setExpand(!expand)}
            aria-label='Expand Options'
            className='cursor-pointer'
          />
        </TextField.Slot>
        <TextField.Slot>
          <IconButton radius='full' aria-label='Search' onClick={handleSearch}>
            <MagnifyingGlassIcon className='cursor-pointer' width='18' height='18' />
          </IconButton>
        </TextField.Slot>
      </TextField.Root>
      {expand
        ? <Flex direction='column'>
            <Flex className='items-center my-2'>
              <Text className='mr-4'>Bedrooms from</Text>
              <TextField.Input
                type='number'
                step='1'
                min='0'
                value={bedroomsRange.min}
                onChange={handleMinRoomsChange}
                className='input-field'
              />
              <Text className='mx-4'>to</Text>
              <TextField.Input
                type='number'
                step='1'
                max='15'
                value={bedroomsRange.max}
                onChange={handleMaxRoomsChange}
                className='input-field'
              />
            </Flex>
            <Flex className='items-center my-2'>
              <Text as='p' className='w-36' name='date-range'>Date range:</Text>
              <Datepicker
                value={value}
                onChange={handleValueChange}
                />
            </Flex>
            <Flex className='items-center my-2'>
              <Text as='p' className='mr-4'>Price from</Text>
              <TextField.Input
                value={priceRange.min}
                type='number'
                step='0.01'
                min='0'
                onChange={handleMinPriceChange}
                className='input-field'
                name='min-price'
              />
              <Text as='p' className='mx-4'>to</Text>
              <TextField.Input
                value={priceRange.max}
                type='number'
                step='0.01'
                onChange={handleMaxPriceChange}
                className='input-field'
                name='max-price'
              />
            </Flex>
            <Flex className='items-center my-2'>
              <Text as='p' className='mr-4'>Rate by: </Text>
              <Select.Root defaultValue={orderby} onValueChange={handleOrderbyChange}>
                <Select.Trigger className='w-40' />
                <Select.Content>
                  <Select.Group>
                    <Select.Item value='default'>Default rating</Select.Item>
                    <Select.Item value='high-to-low'>Rating high to low</Select.Item>
                    <Select.Item value='low-to-high'>Raating low to high</Select.Item>
                  </Select.Group>
                </Select.Content>
              </Select.Root>
            </Flex>
          </Flex>
        : <></>}
      <Text className='text-xl font-medium mt-4'>Search from {value.startDate} to {value.endDate} </Text>
    </Flex>
  )
}

export default SearchBar;
