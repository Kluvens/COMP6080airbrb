import React from 'react';
import {
  useNavigate,
} from 'react-router-dom';
import * as Form from '@radix-ui/react-form';
import { Button, Flex } from '@radix-ui/themes';
import { apiCall } from '../../utils/Helper';
import { EnvelopeClosedIcon, LockClosedIcon } from '@radix-ui/react-icons'

const Login = () => {
  const navigate = useNavigate();
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = Object.fromEntries(new FormData(event.currentTarget));
    const { email, password } = formData;
    // Call the login API
    const data = await apiCall('/user/auth/login', 'POST', { email, password }, null);
    if (data) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('email', email);
      navigate('/');
    } else {
      console.log('failed');
    }
  }

  return (
    <Flex className='min-h-[600px] justify-center items-center'>
      <Form.Root className='w-72 mx-auto' onSubmit={handleSubmit}>
        {/* Email */}
        <Form.Field className='grid mb-3' name='email'>
        <Flex className='items-baseline justify-between'>
            <Form.Label className={'text-purple-500 form-label flex flex-row'}>
            <EnvelopeClosedIcon className='mt-2 mr-3' />  Email
            </Form.Label>
            <Form.Message className= 'font-small' match='valueMissing'>Please enter an email</Form.Message>
            <Form.Message className= 'font-small' match='typeMismatch'>Please enter an valid email</Form.Message>
        </Flex>
        <Form.Control className='form-input w-full pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400' type='email' required placeholder='Enter your email here' />
        </Form.Field>
        {/* Password */}
        <Form.Field className='grid mb-3' name='password'>
        <Flex className='items-baseline justify-between'>
            <Form.Label className={'text-purple-500 form-label flex flex-row'}>
            <LockClosedIcon className='mt-2 mr-3'/> Password
            </Form.Label>
            <Form.Message className='font-small' match='valueMissing'>Please enter a password</Form.Message>
        </Flex>
        <Form.Control className='form-input w-full pl-5 border-2 rounded-xl outline-none bg-gray-50 text-gray-900 transition-all ease-in-out duration-500 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-300/30 placeholder-gray-400' type='password' required placeholder='Enter your password here' />
        </Form.Field>
        {/* Submit */}
        <Form.Submit asChild>
            <Flex className='justify-center'>
                <Button className='cursor-pointer text-white font-bold shadow-md hover:scale-[1.2] shadow-purple-400 rounded-full w-1/2 mt-2 px-5 py-2 bg-gradient-to-bl from-purple-500 to-purple-800' >Submit</Button>
            </Flex>
        </Form.Submit>
      </Form.Root>
    </Flex>
  )
};

export default Login;
