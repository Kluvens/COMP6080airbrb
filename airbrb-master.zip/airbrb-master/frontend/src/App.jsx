import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './pages/Login/Login';
import Register from './pages/Register/Register';
import Home from './pages/Home/Home';
import HostedCreation from './pages/HostedCreation/HostedCreation';
import HostedEdit from './pages/HostedEdit/HostedEdit';
import NotFound from './pages/404/NotFound';
import HostedDetails from './pages/HostedDetails/HostedDetails';
import Hosted from './pages/Hosted/Hosted';
import Publish from './pages/Publish/Publish';
import Booking from './pages/Booking/Booking';
import ListingDetailsPage from './pages/ListingDetailsPage/ListingDetailsPage';

function App () {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='*' element={<NotFound />} />
        <Route path='/hosted' element={<Hosted />} />
        <Route path='/hosted/:listingId' element={<HostedDetails />} />
        <Route path='/listings/new' element={<HostedCreation />} />
        <Route path='/listings/:listingId' element={<ListingDetailsPage />} />
        <Route path='/listings/edit/:listingId' element={<HostedEdit />} />
        <Route path='/publish/:listingId' element={<Publish />} />
        <Route path='/booking/:listingId' element={<Booking />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
