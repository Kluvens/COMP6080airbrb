import { useNavigate } from 'react-router-dom';
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import NotFound from '../pages/404/NotFound';
import { Theme } from '@radix-ui/themes';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

test('renders NotFound component and navigates home on button click', () => {
  const mockNavigate = jest.fn();
  jest.mocked(useNavigate).mockImplementation(() => mockNavigate);

  render(<Theme><NotFound /></Theme>);

  // Check for the presence of text elements
  expect(screen.getByText('404')).toBeInTheDocument();
  expect(screen.getByText('Page not found')).toBeInTheDocument();
  expect(screen.getByText('Sorry, we could not find the page you are looking for')).toBeInTheDocument();

  // Simulate clicking the "Go back home" button
  fireEvent.click(screen.getByText('Go back home'));

  // Verify that navigate was called with the correct argument
  expect(mockNavigate).toHaveBeenCalledWith('/');
});
