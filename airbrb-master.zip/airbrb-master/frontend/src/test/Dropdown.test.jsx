import React from 'react';
import { render, screen } from '@testing-library/react';
import AuthDropdown from '../components/AuthDropdown/AuthDropdown';
import { MemoryRouter } from 'react-router-dom';
import { Theme } from '@radix-ui/themes';

Storage.prototype.getItem = jest.fn();

test('dropdown menu displayed on the screen', async () => {
  Storage.prototype.getItem.mockReturnValue('');
  render(
    <MemoryRouter>
      <Theme>
        <AuthDropdown />
      </Theme>
    </MemoryRouter>
  );

  // Checking if the dropdown trigger is in the document
  const triggerButton = screen.getByTestId('dropdown-trigger');
  expect(triggerButton).toBeInTheDocument();
  expect(triggerButton.querySelector('svg')).toBeInTheDocument();
});
