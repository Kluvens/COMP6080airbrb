import React from 'react'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Login from '../components/Login/Login'

jest.mock('react-router-dom', () => ({
  useNavigate: () => jest.fn(),
}));
jest.mock('../utils/Helper', () => ({
  apiCall: jest.fn(),
}));

describe('Login', () => {
  it('enter inputs for email and password ', () => {
    render(<Login />);

    const emailInput = screen.getByPlaceholderText(/Enter your email here/i);
    const passwordInput = screen.getByPlaceholderText(/Enter your password here/i);
    userEvent.type(emailInput, 'ss@ss.com');
    userEvent.type(passwordInput, 'password123456');

    expect(emailInput).toHaveValue('ss@ss.com');
    expect(passwordInput).toHaveValue('password123456');
  });

  it('displays an error message for invalid email format', () => {
    render(<Login />);

    const emailInput = screen.getByPlaceholderText(/Enter your email here/i);
    userEvent.type(emailInput, '1');

    emailInput.blur();

    expect(screen.getByText(/Please enter an valid email/i)).toBeInTheDocument();
  });
});
