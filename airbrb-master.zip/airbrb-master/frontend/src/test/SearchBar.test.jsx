import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import SearchBar from '../components/SearchBar/SearchBar';

describe('SearchBar ', () => {
  it('click the search button and expand button', () => {
    render(<SearchBar onSearch={jest.fn()} />);
    expect(screen.getByPlaceholderText('Search the docs…')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Expand Options' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Search' })).toBeInTheDocument();
  });

  it('allows typing in the search input', () => {
    render(<SearchBar onSearch={jest.fn()} />);
    userEvent.type(screen.getByPlaceholderText('Search the docs…'), 'NSW');
    expect(screen.getByPlaceholderText('Search the docs…')).toHaveValue('NSW');
  });

  it('calls onSearch prop when search button is clicked', () => {
    const mockOnSearch = jest.fn();
    render(<SearchBar onSearch={mockOnSearch} />);
    const searchInput = screen.getByPlaceholderText('Search the docs…');
    userEvent.type(searchInput, 'NSW');
    fireEvent.click(screen.getByRole('button', { name: 'Search' }));
    expect(mockOnSearch).toHaveBeenCalledWith('NSW', expect.anything(), expect.anything(), expect.anything(), expect.anything());
  });
});
