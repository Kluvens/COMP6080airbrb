import React from 'react';
import { render, screen } from '@testing-library/react';
import { Theme } from '@radix-ui/themes';
import ButtonTesting from '../components/ButtonTesting/ButtonTesting';

test('submits a review and shows update', async () => {
  render(
    <Theme>
      <ButtonTesting className='custom-button-class' />
    </Theme>
  );

  const buttonText = screen.getByText('Testing');
  expect(buttonText).toBeInTheDocument();
});
