import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { useNavigate } from 'react-router-dom';
import Listing from '../components/Listings/Listing/Listing';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

const mockProps = {
  id: '123',
  title: 'Sample Listing',
  price: '100',
  thumbnail: 'https://example.com/sample.jpg',
  reviews: [{}, {}, {}],
};

test('renders Listing component and navigates on click', () => {
  const mockNavigate = jest.fn();
  jest.mocked(useNavigate).mockImplementation(() => mockNavigate);

  render(<Listing {...mockProps} />);

  // Verifying that the component renders with correct title
  const listingElement = screen.getByText(mockProps.title);
  expect(listingElement).toBeInTheDocument();

  // Simulating a click on the listing
  fireEvent.click(listingElement);
  expect(mockNavigate).toHaveBeenCalledWith('/listings/' + mockProps.id);
});
