export const apiCall = async (path, method, body, token) => {
  const fetchOptions = {
    method,
    headers: {
      'Content-Type': 'application/json',
      Authorization: token ? `Bearer ${token}` : undefined,
    }
  };
  if (body !== null) {
    fetchOptions.body = JSON.stringify(body);
  }
  const response = await fetch('http://localhost:5005' + path, fetchOptions);
  const data = await response.json();
  if (data.error) {
    alert(data.error);
  } else {
    return data;
  }
};

export const fileToDataUrl = (file) => {
  const validFileTypes = ['image/jpeg', 'image/png', 'image/jpg']
  const valid = validFileTypes.find(type => type === file.type);
  if (!valid) {
    throw Error('provided file is not a png, jpg or jpeg image.');
  }
  const reader = new FileReader();
  const dataUrlPromise = new Promise((resolve, reject) => {
    reader.onerror = reject;
    reader.onload = () => resolve(reader.result);
  });
  reader.readAsDataURL(file);
  return dataUrlPromise;
}

export const formDataToHostedCreation = async (formData) => {
  const listingCreation = {};
  listingCreation.title = formData.title;
  listingCreation.address = {
    street: formData.street,
    suburb: formData.suburb,
    state: formData.state,
  };
  listingCreation.price = parseFloat(formData.price_per_night);
  try {
    listingCreation.thumbnail = await fileToDataUrl(formData.thumbnail_upload);
  } catch {
    listingCreation.thumbnail = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAAAAAByaaZbAAAA90lEQVR4Ae3UJ4PDMAyG4fv1HxMTK6tRWYJ6zCxMLCxFFxQzsbDubVexb68X68m0/TQW9mngH2izYICdhDzgCcfYZ4BhjqtmYQoMjJtYJ0CFu5wNBFGdCTgGzgIvSNQZoEmBxgB1CtRfCnwKeAOsSr+SEqJ4jIH5TN4EytEN1ARjT7iJ+qn90FI0b4MxMM7NQ9aeFncc77JPDV210us3OZdUlgtm7KOZW7bBAtrMEeUkPABDRUhXhQRQT3icj0DPMONwC4QwEck1EGQkF9Aiq+4EBs4DFI6gQmbuAFbIrtsDlw/cDgwoSLdASoBswXMJWG5BXQLqcQOKfxhbw9MxtAAAAABJRU5ErkJggg==';
  }
  listingCreation.metadata = {
    property_type: formData.property_type,
    num_bathrooms: formData.bathrooms,
    num_bedrooms: formData.bedrooms,
    num_beds: formData.beds,
    amenities: {
      air_conditioning: formData.air_conditioning || 'off',
      heater: formData.heater || 'off',
    }
  }

  return listingCreation;
}
