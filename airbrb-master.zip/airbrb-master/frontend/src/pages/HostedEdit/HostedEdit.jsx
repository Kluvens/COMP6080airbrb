import React, { useState, useEffect } from 'react';
import { Flex, Heading, Text, TextField, Separator, Button, Select, Checkbox } from '@radix-ui/themes';
import { Label } from '@radix-ui/react-label';
import { useParams, useNavigate } from 'react-router-dom';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import FireplaceIcon from '@mui/icons-material/Fireplace';
import { apiCall, fileToDataUrl } from '../../utils/Helper';
import Navbar from '../../components/Navbar/Navbar';

const HostedEdit = () => {
  const token = localStorage.getItem('token');
  const { listingId } = useParams();
  const navigate = useNavigate();
  const [listingDetails, setListingDetails] = useState({});

  useEffect(() => {
    const fetchListingDetails = async () => {
      try {
        const response = await apiCall('/listings/' + listingId, 'GET', null, token);
        if (response) {
          const listing = response.listing;
          setListingDetails({
            title: listing.title,
            street: listing.address.street || '',
            suburb: listing.address.suburb || '',
            state: listing.address.state || '',
            price: listing.price || '',
            propertyType: listing.metadata.property_type || '',
            thumbnail: listing.thumbnail || '',
            bathrooms: listing.metadata.num_bathrooms || 0,
            bedrooms: listing.metadata.num_bedrooms || 0,
            beds: listing.metadata.num_beds || 0,
            amenities: {
              air_conditioning: listing.metadata.amenities.air_conditioning || 'off',
              heater: listing.metadata.amenities.heater || 'off',
            },
            images: listing.metadata.images || [],
          });
        }
      } catch (error) {
        console.error('Error fetching listing details:', error);
      }
    };
    fetchListingDetails();
  }, [listingId, token]);
  // Adjust input is edit or not
  const [editStates, setEditStates] = useState({
    title: false,
    street: false,
    suburb: false,
    state: false,
    price: false,
    thumbnail: false,
    propertyType: false,
    bathrooms: false,
    bedrooms: false,
    beds: false,
    amenities: false,
    images: false,
  });
  // Submit the form
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await apiCall(`/listings/${listingId}`, 'PUT', {
        title: listingDetails.title,
        address: {
          street: listingDetails.street,
          suburb: listingDetails.suburb,
          state: listingDetails.state,
        },
        thumbnail: listingDetails.thumbnail,
        price: listingDetails.price,
        metadata: {
          property_type: listingDetails.propertyType,
          num_bathrooms: listingDetails.bathrooms,
          num_bedrooms: listingDetails.bedrooms,
          num_beds: listingDetails.beds,
          amenities: {
            air_conditioning: listingDetails.amenities.air_conditioning,
            heater: listingDetails.amenities.heater,
          },
          images: listingDetails.images,
        },
      }, token);
      if (response) {
        navigate(`/listings/${listingId}`);
      } else {
        console.log('Update failed');
      }
    } catch (error) {
      console.error('Error submitting listing:', error);
    }
  };

  const toggleEditing = (field) => {
    setEditStates(prev => ({ ...prev, [field]: !prev[field] }));
  };
  // Detect any value change
  const handleInputChange = async (e, field) => {
    let value = e.target.value;
    if (field === 'thumbnail') {
      const file = e.target.files[0];
      if (file) {
        value = await fileToDataUrl(file) || '';
        setListingDetails(prev => ({ ...prev, [field]: value }));
      }
    } else if (field === 'images') {
      const newImages = [];
      const files = e.target.files;
      for (const file of files) {
        const image = await fileToDataUrl(file) || '';
        newImages.push(image);
      }
      setListingDetails(prev => ({ ...prev, [field]: [...prev.images, ...newImages] }));
    } else {
      setListingDetails(prev => ({ ...prev, [field]: value }));
    }
  };
  // Delete the image from list of preperty images
  const handleDeleteImage = (e, index) => {
    e.preventDefault();
    setListingDetails(prev => {
      const updatedImages = prev.images.filter((_, idx) => idx !== index);
      return { ...prev, images: updatedImages };
    });
  };

  const handleInputValueChange = (value, field) => {
    setListingDetails(prev => ({ ...prev, [field]: value }));
  }
  // Adjust the amenities change or not
  const handleCheckboxChange = (value, field) => {
    setListingDetails(prev => ({
      ...prev,
      amenities: {
        ...prev.amenities,
        [field]: value ? 'on' : 'off',
      }
    }));
  }

  return (
    <>
      <Flex className='flex-col mx-auto px-4 sm:px-16 lg:px-24 xl:px-48'>
        <Navbar />
        <Heading className='text-2xl font-bold'> Edit Listing</Heading>
        <form onSubmit={handleSubmit}>
          <Flex direction='column'>
            <Flex direction='column'>
              <Flex direction='column' className='justify-between mt-3'>
                {/* Title */}
                <Flex className='justify-between mt-3'>
                  <Label htmlFor='title' className='text-lg font-medium'>Title</Label>
                  <Text onClick={() => toggleEditing('title')} className='underline cursor-pointer'>
                    {editStates.title ? 'Temp save' : 'Edit'}
                  </Text>
                </Flex>
                {editStates.title
                  ? <TextField.Input
                      id='title'
                      name='title'
                      value={listingDetails.title || ''}
                      onChange={(e) => handleInputChange(e, 'title')}
                      className='input-field'
                    />
                  : <Text className='mt-2 text-gray-500'>{listingDetails.title}</Text>
                }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Address */}
              <Flex className='grid grid-cols-1 gap-x-4 lg:grid-cols-3 lg:gap-x-12'>
                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='street' className='text-lg font-medium'>Street</Label>
                    <Text onClick={() => toggleEditing('street')} className='underline cursor-pointer'>
                      {editStates.street ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.street
                    ? <TextField.Input
                        id='street'
                        name='street'
                        value={listingDetails.street || ''}
                        onChange={(e) => handleInputChange(e, 'street')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.street}</Text>
                  }
                </Flex>

                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='suburb' className='text-lg font-medium'>Suburb</Label>
                    <Text onClick={() => toggleEditing('suburb')} className='underline cursor-pointer'>
                      {editStates.suburb ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.suburb
                    ? <TextField.Input
                        id='suburb'
                        name='suburb'
                        value={listingDetails.suburb || ''}
                        onChange={(e) => handleInputChange(e, 'suburb')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.suburb}</Text>
                  }
                </Flex>

                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='state' className='text-lg font-medium'>State</Label>
                    <Text onClick={() => toggleEditing('state')} className='underline cursor-pointer'>
                      {editStates.state ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.state
                    ? <TextField.Input
                        id='state'
                        name='state'
                        value={listingDetails.state || ''}
                        onChange={(e) => handleInputChange(e, 'state')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.state}</Text>
                  }
                </Flex>
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Price */}
              <Flex direction='column' className='justify-between mt-3'>
                <Flex className='justify-between mt-3'>
                  <Label htmlFor='price' className='text-lg font-medium'>Price</Label>
                  <Text onClick={() => toggleEditing('price')} className='underline cursor-pointer'>
                    {editStates.price ? 'Temp save' : 'Edit'}
                  </Text>
                </Flex>
                {editStates.price
                  ? <TextField.Input
                      id='price'
                      name='price'
                      type='number'
                      min='0'
                      value={listingDetails.price || ''}
                      onChange={(e) => handleInputChange(e, 'price')}
                      className='input-field'
                    />
                  : <Text className='mt-2 text-gray-500'>{listingDetails.price}</Text>
                }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Thumbnail */}
              <Flex direction='column' className='justify-between mt-3'>
                <Flex className='justify-between mt-3'>
                  <Label htmlFor='thumbnail' className='text-lg font-medium'>Thumbnail</Label>
                  <Text onClick={() => toggleEditing('thumbnail')} className='underline cursor-pointer'>
                    {editStates.thumbnail ? 'Temp save' : 'Edit'}
                  </Text>
                </Flex>
                {editStates.thumbnail
                  ? <>
                      <img className='w-32 h-32 object-cover' src={listingDetails.thumbnail} alt={`${listingDetails.title} thumbnail`} />
                      <Flex className='mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10'>
                        <Flex direction='column' className='text-center'>
                          <Label htmlFor='thumbnail' className='relative cursor-pointer rounded-md bg-white font-semibold text-indigo-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-600 focus-within:ring-offset-2 hover:text-indigo-500'>
                            <Text as='span'>Upload files</Text>
                            <TextField.Input
                              id='thumbnail'
                              name='thumbnail'
                              type='file'
                              accept='.jpg, .jpeg, .png'
                              className='sr-only input-field'
                              onChange={(e) => handleInputChange(e, 'thumbnail')}
                            />
                          </Label>
                          <Text as='p' className='mt-1 text-xs leading-5 text-gray-600'>Support JPG, PNG, JEPG files</Text>
                        </Flex>
                      </Flex>
                    </>
                  : <img className='w-1/2'
                      src={listingDetails.thumbnail}
                      alt={`${listingDetails.title} thumbnail`}
                    />
                }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Property type */}
              <Flex direction='column' className='justify-between mt-3'>
                <Flex className='justify-between mt-3'>
                  <Label htmlFor='propertyType' className='text-lg font-medium'>Property Type</Label>
                  <Text onClick={() => toggleEditing('propertyType')} className='underline cursor-pointer'>
                    {editStates.propertyType ? 'Temp save' : 'Edit'}
                  </Text>
                </Flex>
                {editStates.propertyType
                  ? <Flex>
                      <Select.Root name='propertyType' defaultValue={listingDetails.propertyType} onValueChange={(value) => handleInputValueChange(value, 'propertyType')}>
                        <Select.Trigger />
                        <Select.Content>
                          <Select.Group>
                            <Select.Item value='House'>House</Select.Item>
                            <Select.Item value='Apartment'>Apartment</Select.Item>
                          </Select.Group>
                        </Select.Content>
                      </Select.Root>
                    </Flex>
                  : <Text className='mt-2 text-gray-500'>{listingDetails.propertyType}</Text>
                }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Number of bathrooms */}
              <Flex className='grid grid-cols-1 gap-x-4 lg:grid-cols-3 lg:gap-x-12'>
                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='bathrooms' className='text-lg font-medium'>Bathrooms</Label>
                    <Text onClick={() => toggleEditing('bathrooms')} className='underline cursor-pointer'>
                      {editStates.bathrooms ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.bathrooms
                    ? <TextField.Input
                        id='bathrooms'
                        name='bathrooms'
                        type='number'
                        min='0'
                        max='15'
                        value={listingDetails.bathrooms || ''}
                        onChange={(e) => handleInputChange(e, 'bathrooms')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.bathrooms}</Text>
                  }
                </Flex>
                {/* Beedrooms */}
                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='bedrooms' className='text-lg font-medium'>bedrooms</Label>
                    <Text onClick={() => toggleEditing('bedrooms')} className='underline cursor-pointer'>
                      {editStates.bedrooms ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.bedrooms
                    ? <TextField.Input
                        id='bedrooms'
                        name='bedrooms'
                        type='number'
                        min='0'
                        max='15'
                        value={listingDetails.bedrooms || ''}
                        onChange={(e) => handleInputChange(e, 'bedrooms')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.bedrooms}</Text>
                  }
                </Flex>
                <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='beds' className='text-lg font-medium'>beds</Label>
                    <Text onClick={() => toggleEditing('beds')} className='underline cursor-pointer'>
                      {editStates.beds ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.beds
                    ? <TextField.Input
                        id='beds'
                        name='beds'
                        type='number'
                        min='0'
                        max='15'
                        value={listingDetails.beds || ''}
                        onChange={(e) => handleInputChange(e, 'beds')}
                        className='input-field'
                      />
                    : <Text className='mt-2 text-gray-500'>{listingDetails.beds}</Text>
                  }
                </Flex>
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* Amenities */}
              <Flex direction='column' className='justify-between mt-3'>
                  <Flex className='justify-between mt-3'>
                    <Label htmlFor='amenities' className='text-lg font-medium'>Amenities</Label>
                    <Text onClick={() => toggleEditing('amenities')} className='underline cursor-pointer'>
                      {editStates.amenities ? 'Temp save' : 'Edit'}
                    </Text>
                  </Flex>
                  {editStates.amenities
                    ? (
                      <Flex direction='column' className='mt-2 space-y-6'>
                        <Flex className='gap-2'>
                          <Checkbox
                            value='air_conditioning'
                            id='air_conditioning'
                            defaultChecked={listingDetails.amenities && listingDetails.amenities.air_conditioning === 'on'}
                            onCheckedChange={checked => handleCheckboxChange(checked, 'air_conditioning')}
                            className='bg-violet-700 mt-1'/>
                          <Label htmlFor='air_conditioning'>Air conditioning</Label>
                        </Flex>
                        <Flex className='gap-2'>
                          <Checkbox
                            value='heater'
                            id='heater'
                            defaultChecked={listingDetails.amenities && listingDetails.amenities.heater === 'on'}
                            onCheckedChange={checked => handleCheckboxChange(checked, 'heater')}
                            className='bg-violet-700 mt-1'/>
                          <Label htmlFor='heater'>Heater</Label>
                        </Flex>
                      </Flex>
                      )
                    : (
                      <Flex direction='column'>
                        <Text className={`flex py-2 ${listingDetails.amenities && listingDetails.amenities.air_conditioning === 'on' ? '' : 'line-through'}`}>
                          <AcUnitIcon className='mr-2'/> Air Conditioning
                        </Text>
                        <Text className={`flex py-2 ${listingDetails.amenities && listingDetails.amenities.heater === 'on' ? '' : 'line-through'}`}>
                          <FireplaceIcon className='mr-2'/> Heater
                        </Text>
                      </Flex>
                      )
                  }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              {/* List of preperty images */}
              <Flex direction='column' className='justify-between mt-3'>
                <Flex className='justify-between mt-3'>
                  <Label htmlFor='images' className='text-lg font-medium'>Property images</Label>
                  <Text onClick={() => toggleEditing('images')} className='underline cursor-pointer'>
                    {editStates.images ? 'Temp save' : 'Edit'}
                  </Text>
                </Flex>
                {editStates.images
                  ? <Flex direction='column'>
                      <Flex className='grid grid-cols-2'>
                        {listingDetails.images && listingDetails.images.map((image, idx) => (
                          <div key={idx} className='relative'>
                            <img className='w-full' src={image} alt={`${listingDetails.title} property image ${idx}`} />
                            <Button
                              className='absolute top-0 right-0 bg-red-500 text-white p-1 cursor-pointer'
                              onClick={(e) => handleDeleteImage(e, idx)}
                            >
                              Delete
                            </Button>
                        </div>
                        ))}
                      </Flex>
                      <Flex className='mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10'>
                        <Flex direction='column' className='text-center'>
                          <Label htmlFor='images' className='relative cursor-pointer rounded-md bg-white font-semibold text-indigo-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-600 focus-within:ring-offset-2 hover:text-indigo-500'>
                            <Text as='span'>Upload files</Text>
                            <TextField.Input
                              name='images'
                              id='images'
                              type='file'
                              className='sr-only input-field'
                              required
                              accept='.jpg, .jpeg, .png'
                              onChange={(e) => handleInputChange(e, 'images')}
                              multiple
                            />
                          </Label>
                          <Text as='p' className='mt-1 text-xs leading-5 text-gray-600'>Support JPG, PNG, JEPG files</Text>
                        </Flex>
                      </Flex>
                    </Flex>
                  : <Flex className='grid grid-cols-2'>
                      {listingDetails.images && listingDetails.images.map((image, idx) => (
                        <img key={idx} className='w-full h-full object-cover' src={image} alt={`${listingDetails.title} property image ${idx}`} />
                      ))}
                    </Flex>
                }
              </Flex>
              <Separator className='mt-2' orientation='horizontal' size='auto' />
              <Button className='mt-5 cursor-pointer'>Save changes</Button>
            </Flex>
          </Flex>
        </form>
      </Flex>
    </>
  )
}

export default HostedEdit;
