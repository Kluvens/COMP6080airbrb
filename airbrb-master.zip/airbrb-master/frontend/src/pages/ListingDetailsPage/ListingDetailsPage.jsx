import React from 'react';
import Navbar from '../../components/Navbar/Navbar';
import ListingDetails from '../../components/ListingDetails/ListingDetails';
import { Flex } from '@radix-ui/themes';

const ListingDetailsPage = () => {
  return (
    <Flex direction='column px-4 sm:px-16 lg:px-24 xl:px-48'>
      <Navbar />
      <ListingDetails />
    </Flex>

  )
}

export default ListingDetailsPage;
