import React from 'react';
import { Flex, Separator } from '@radix-ui/themes';
import Navbar from '../../components/Navbar/Navbar';
import Login from '../../components/Login/Login';

const LoginPages = () => {
  return (
    <Flex className='flex-col min-h-screen w-4/5 mx-auto'>
      <Navbar/>
      <Separator className='mt-2 ml-8 mr-8' orientation='horizontal' size='auto' />
      <Login />
    </Flex>

  )
};

export default LoginPages;
