import React from 'react';
import HostedListings from '../../components/HostedListings/HostedListings';
import { Button, Flex, Heading } from '@radix-ui/themes';
import { useNavigate } from 'react-router-dom';
import Navbar from '../../components/Navbar/Navbar';
import { PlusIcon } from '@radix-ui/react-icons';

const Hosted = () => {
  const navigate = useNavigate();
  const handleCreateNew = () => {
    navigate('/listings/new')
  }
  return (
    <Flex className='flex-col mx-auto px-4 sm:px-16 lg:px-24 xl:px-48'>
      <Navbar/>
      <Heading className='text-xl flex items-center'>My hosted Listing :
        <Button className='cursor-pointer ml-4' onClick={handleCreateNew}>
            <PlusIcon />Create new
          </Button>
      </Heading>
      <HostedListings/>
    </Flex>
  )
}

export default Hosted;
