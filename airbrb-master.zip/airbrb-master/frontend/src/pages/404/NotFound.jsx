import React from 'react';
import { Flex, Text, Button } from '@radix-ui/themes';
import Navbar from '../../components/Navbar/Navbar';
import { useNavigate } from 'react-router-dom';

const NotFound = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/');
  }

  return (
    <Flex direction='column'>
      <Navbar />
      <Flex className='grid absolute h-screen w-screen place-items-center justify-center bg-transparent'>
        <Flex direction='column' className='text-center'>
          <Text as='p' className='text-2xl font-semibold text-indigo-600'>404</Text>
          <Text className='mt-4 text-3xl font-bold tracking-tight text-gray-900 sm:text-5xl'>Page not found</Text>
          <Text className='mt-6 text-base leading-7 text-gray-600'>Sorry, we could not find the page you are looking for</Text>
          <Flex className='mt-6 flex items-center justify-center gap-x-6'>
            <Button className='cursor-pointer' onClick={handleClick}>Go back home</Button>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  )
}

export default NotFound;
