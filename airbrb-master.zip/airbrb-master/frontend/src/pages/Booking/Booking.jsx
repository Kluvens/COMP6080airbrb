import { Flex, Button } from '@radix-ui/themes';
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Datepicker from 'react-tailwindcss-datepicker';
import { apiCall } from '../../utils/Helper';

const Booking = () => {
  const { listingId } = useParams();
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const navigate = useNavigate();
  const [value, setValue] = useState(() => {
    const start = new Date();
    const end = new Date();
    end.setDate(start.getDate() + 1);
    return {
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
    };
  });
  const [listing, setListing] = useState({});
  useEffect(() => {
    if (!token || !email) {
      navigate('/login');
    }
    const fetchData = async () => {
      const data = await apiCall('/listings/' + listingId, 'GET', null, token);
      setListing(data.listing);
    };
    fetchData();
  }, []);
  const handleValueChange = (newValue) => {
    setValue(newValue);
  }
  // Booking submission
  const handleBookingSubmission = async () => {
    const data = await apiCall('/bookings/new/' + listingId, 'POST', {
      dateRange: value,
      totalPrice: parseFloat(listing.price) * ((new Date(value.endDate) - new Date(value.startDate)) / (1000 * 60 * 60 * 24)).toString(),
    }, token);
    console.log(data);
  }
  return (
    <Flex direction='column'>
      <Flex>{listingId}</Flex>
      <Datepicker
        value={value}
        onChange={handleValueChange}
      />
      <Flex>Total price is: {parseFloat(listing.price) * ((new Date(value.endDate) - new Date(value.startDate)) / (1000 * 60 * 60 * 24))}</Flex>
      <Button onClick={handleBookingSubmission}>Submit</Button>
    </Flex>
  )
}

export default Booking;
