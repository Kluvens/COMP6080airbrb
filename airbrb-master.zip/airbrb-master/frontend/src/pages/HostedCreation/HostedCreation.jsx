import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, TextField, Flex, Select, Text, Checkbox, Separator } from '@radix-ui/themes';
import { Label } from '@radix-ui/react-label';
import Navbar from '../../components/Navbar/Navbar';
import { apiCall, formDataToHostedCreation, fileToDataUrl } from '../../utils/Helper';
// Create a hosted listing
const HostedCreation = () => {
  const token = localStorage.getItem('token');
  const [thumbnail, setThumbnail] = useState('');

  const handleThumbnailUpload = async (e) => {
    const file = e.target.files[0];
    const currentThumbnail = await fileToDataUrl(file);
    setThumbnail(currentThumbnail);
  }

  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = Object.fromEntries(new FormData(e.currentTarget));
    const { title, street, suburb, state } = formData;
    if (!title.trim() || !street.trim() || !suburb.trim() || !state.trim()) {
      alert('Fields cannot be empty or just whitespace.');
      return;
    }
    const listingCreation = await formDataToHostedCreation(formData);

    const data = await apiCall('/listings/new', 'POST', listingCreation, token);
    if (data) {
      navigate('/hosted/');
      alert('Create success');
    } else {
      console.log('failed');
    }
  }

  return (
    <Flex className='flex-col px-4 py-4 sm:px-8 lg:px-16 xl:px-24'>
      <Navbar/>
      <form onSubmit={handleSubmit} className='py-4'>
        <Text className='text-lg font-bold'>Create your listing</Text>
        <Flex direction='column'>
          <Flex direction='column' className='mt-4'>
            <Label htmlFor='title' className='text-base mb-2 font-medium leading-7'>
              Title
            </Label>
            <TextField.Input
              placeholder='Enter title of your place'
              id='title'
              name='title'
              className='input-field ml-2'
              required
            />
          </Flex>
          <Flex className='grid grid-cols-3 gap-x-4 sm:gap-x-8 lg:gap-x-12 xl:gap-x-16'>
            <Flex direction='column' className='mt-4'>
              <Label htmlFor='street' className='block mb-2 text-base font-medium leading-6 text-gray-900'>
                Street address
              </Label>
              <TextField.Input
                placeholder='Enter street of your place'
                type='text'
                name='street'
                id='street'
                autoComplete='street_address'
                className='input-field placeholder:text-sm'
                required
              />
            </Flex>
            <Flex direction='column' className='mt-4'>
              <Label htmlFor='suburb' className='block mb-2 text-base font-medium leading-6 text-gray-900'>
                Suburb
              </Label>
              <TextField.Input
                placeholder='Enter suburb of your place'
                type='text'
                name='suburb'
                id='suburb'
                autoComplete='address-level2'
                className='input-field placeholder:text-sm'
                required
              />
            </Flex>
            <Flex direction='column' className='mt-4'>
              <Label htmlFor='state' className='block mb-2 text-base font-medium leading-6 text-gray-900'>
                State
              </Label>
              <TextField.Input
                placeholder='Enter state of your place'
                type='text'
                name='state'
                id='state'
                autoComplete='address-level1'
                className='input-field placeholder:text-sm'
                required
              />
            </Flex>
          </Flex>
          <Flex className='mt-4'>
            <Label htmlFor='price_per_night' className='text-base font-medium leading-6 mr-8'>Price per night</Label>
            <TextField.Input name='price_per_night' id='_per' min='1' max='3000' step='0.01' type='number' className='w-40 input-field' required/>
          </Flex>
          <Flex className='mt-4'>
            <Label className='text-base font-medium leading-6 mr-8'>Property type</Label>
            <Select.Root name='property_type' defaultValue='House'>
              <Select.Trigger />
              <Select.Content>
                <Select.Group>
                  <Select.Item value='House'>House</Select.Item>
                  <Select.Item value='Apartment'>Apartment</Select.Item>
                </Select.Group>
              </Select.Content>
            </Select.Root>
          </Flex>
          <Flex direction='column' className='mt-4 col-span-full'>
            <Label htmlFor='thumbnail' className='block text-base font-medium leading-6'>
              Thumbnail
            </Label>
            {thumbnail !== '' && <img src={thumbnail} alt='preview of hosted thumbnail' className='my-2 w-full lg:w-2/3' />}
            <Flex id='thumbnail' className='mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10'>
              <Flex direction='column' className='text-center'>
                <Label htmlFor='thumbnail_upload' className='relative cursor-pointer rounded-md bg-white font-semibold text-indigo-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-600 focus-within:ring-offset-2 hover:text-indigo-500'>
                  <Text as='span'>Upload a file</Text>
                  <TextField.Input
                    name='thumbnail_upload'
                    id='thumbnail_upload'
                    type='file'
                    className='sr-only input-field'
                    required
                    accept='.jpg, .jpeg, .png'
                    onChange={handleThumbnailUpload}
                  />
                </Label>
                <Text as='p' className='mt-1 text-xs leading-5 text-gray-600'>Support JPG, PNG, JEPG files</Text>
              </Flex>
            </Flex>
          </Flex>
          <Flex className='mt-4 grid grid-cols-3 gap-x-4 sm:gap-x-8 lg:gap-x-12 xl:gap-x-16'>
            <Flex direction='column'>
              <Label htmlFor='bathrooms' className='text-base font-medium leading-6 mb-2'>Number of bathrooms</Label>
                <TextField.Input name='bathrooms' id='bathrooms' min='0' max='15' type='number' className='input-field' required/>
              </Flex>
              <Flex direction='column'>
                <Label htmlFor='bedrooms' className='text-base font-medium leading-6 mb-2'>Number of bedrooms</Label>
                <TextField.Input name='bedrooms' id='bedrooms' min='0' max='15' type='number' className='input-field' required/>
              </Flex>
              <Flex direction='column'>
                <Label htmlFor='beds' className='text-base font-medium leading-6 mb-2'>Number of beds</Label>
                <TextField.Input name='beds' id='beds' min='1' max='30' type='number' className='input-field' required/>
              </Flex>
            </Flex>
          <Flex className='mt-3 '>
            <fieldset>
              <Text className='font-medium leading-6 text-gray-900'>Amenities:</Text>
              <Flex direction='column' className='mt-3 space-y-6'>
                <Flex className='gap-2'>
                  <Checkbox className='bg-violet-700 mt-1' id='air_conditioning' name='air_conditioning' />
                  <Label htmlFor='air_conditioning'>Air conditioning</Label>
                </Flex>
                <Flex className='gap-2'>
                  <Checkbox id='heater' name='heater' className='bg-violet-700 mt-1'/>
                  <Label htmlFor='heater'>Heater</Label>
                </Flex>
              </Flex>
            </fieldset>
          </Flex>
          <Separator className='mt-5 w-full bg-violet-900 ' orientation='horizontal' size='auto' />
          <Flex className='justify-end'>
            <Button className='mt-3 cursor-pointer'>Submit</Button>
          </Flex>
        </Flex>
      </form>
    </Flex>
  )
}

export default HostedCreation;
