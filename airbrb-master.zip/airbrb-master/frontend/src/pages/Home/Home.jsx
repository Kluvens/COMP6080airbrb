import React, { useState, useEffect } from 'react';
import { Flex } from '@radix-ui/themes';
import Listings from '../../components/Listings/Listings';
import Navbar from '../../components/Navbar/Navbar';
import SearchBar from '../../components/SearchBar/SearchBar';
import { apiCall } from '../../utils/Helper';

const Home = () => {
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const [listings, setListings] = useState([]);
  const [originalListings, setOriginalListings] = useState([]);
  const [priorityList, setPriorityList] = useState([]);
  const [dateRange, setDateRange] = useState({ startDate: '', endDate: '' });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await apiCall('/listings', 'GET', null, null);
        if (data) {
          // sort by alphabetical order
          const hostedListings = [...data.listings].sort((a, b) => a.title.localeCompare(b.title));
          const listingsWithDetails = await Promise.all(hostedListings.map(async (listing) => {
            const response = await apiCall('/listings/' + listing.id, 'GET', null, token);
            return { ...listing, ...response.listing.metadata, availability: response.listing.availability, published: response.listing.published };
          }));
          const publishedListings = listingsWithDetails.filter((listing) => listing.published);
          let priority = [];
          if (token) {
            const bookingData = await apiCall('/bookings', 'GET', null, token);
            if (bookingData) {
              const filteredBookingData = bookingData.bookings.filter((booking) => booking.owner === email && (booking.status === 'accepted' || booking.status === 'pending'));
              priority = filteredBookingData.map(booking => Number(booking.listingId));
              setPriorityList(priority);
            }
          }
          // bookings with pending or accepted should appear in the front
          const displayListings = [...publishedListings].sort((a, b) => {
            const aIsPriority = priority.includes(a.id);
            const bIsPriority = priority.includes(b.id);

            if (aIsPriority === bIsPriority) {
              return a.title.localeCompare(b.title);
            }

            return aIsPriority ? -1 : 1;
          })
          setListings(displayListings);
          setOriginalListings(displayListings);
        } else {
          console.log('failed');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    fetchData();
  }, []);

  const getDatesInRange = (startDate, endDate) => {
    const dateList = [];
    const currentDate = new Date(startDate);

    while (currentDate < new Date(endDate)) {
      dateList.push(currentDate.toISOString().split('T')[0]);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return dateList;
  };
  // Adjust the Search information
  const handleSearch = (query, bedroomsRange, value, priceRange, orderby) => {
    setDateRange(value);
    const lowerQuery = query.toLowerCase();
    let newListings = originalListings.filter((listing) => {
      const lowTitle = listing.title.toLowerCase();
      const lowAddress = `${listing.address.street}, ${listing.address.suburb}, ${listing.address.state}`.toLowerCase();
      const bedrooms = parseInt(listing.num_bedrooms || 0);
      const matchesQuery = lowTitle.includes(lowerQuery) || lowAddress.includes(lowerQuery);
      let matchesBedrooms = true;
      if (bedroomsRange.min !== '' && bedroomsRange.max !== '') {
        matchesBedrooms = bedrooms >= bedroomsRange.min && bedrooms <= bedroomsRange.max;
      } else if (bedroomsRange.min !== '') {
        matchesBedrooms = bedrooms >= bedroomsRange.min;
      } else if (bedroomsRange.max !== '') {
        matchesBedrooms = bedrooms <= bedroomsRange.max;
      }

      const requiredDates = getDatesInRange(value.startDate, value.endDate);
      const validDates = requiredDates.every(date => listing.availability.includes(date));

      const price = parseFloat(listing.price);
      let matchedPrice = true;
      if (priceRange.min !== '' && priceRange.max !== '') {
        const minPrice = parseFloat(priceRange.min);
        const maxPrice = parseFloat(priceRange.max);
        matchedPrice = price >= minPrice && price <= maxPrice;
      } else if (priceRange.min !== '') {
        const minPrice = parseFloat(priceRange.min);
        matchedPrice = price >= minPrice;
      } else if (priceRange.max !== '') {
        const maxPrice = parseFloat(priceRange.max);
        matchedPrice = price <= maxPrice;
      }
      return matchesQuery && matchesBedrooms && validDates && matchedPrice;
    });

    newListings.forEach(listing => {
      const totalRatings = listing.reviews.reduce((total, review) => total + Number(review.rating), 0);
      listing.averageRating = listing.reviews.length > 0 ? totalRatings / listing.reviews.length : 0;
    });
    newListings = newListings.sort((a, b) => {
      const aIsPriority = priorityList.includes(a.id);
      const bIsPriority = priorityList.includes(b.id);

      if (orderby === 'high-to-low') {
        if (aIsPriority === bIsPriority) {
          return b.averageRating - a.averageRating;
        }

        return aIsPriority ? -1 : 1;
      } else {
        if (aIsPriority === bIsPriority) {
          return a.averageRating - b.averageRating;
        }

        return aIsPriority ? -1 : 1;
      }
    });

    if (orderby !== 'high-to-low' && orderby !== 'low-to-high') {
      setListings(originalListings);
    } else {
      setListings(newListings);
    }
  }
  return (
    <Flex className='flex-col mx-auto px-4 sm:px-16 lg:px-24 xl:px-48'>
      <Navbar/>
      <SearchBar onSearch={handleSearch} />
      <Listings className='mt-5' listings={listings} dateRange={dateRange} />
    </Flex>
  )
}

export default Home;
