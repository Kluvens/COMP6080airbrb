import React from 'react';
import { Flex, Separator } from '@radix-ui/themes';
import Navbar from '../../components/Navbar/Navbar';
import Register from '../../components/Register/Register';

const RegisterPages = () => {
  return (
    <Flex className='flex-col min-h-screen w-4/5 mx-auto'>
      <Navbar/>
      <Separator className='mt-2 ml-8 mr-8' orientation='horizontal' size='auto' />
      <Register />
    </Flex>

  )
};

export default RegisterPages;
