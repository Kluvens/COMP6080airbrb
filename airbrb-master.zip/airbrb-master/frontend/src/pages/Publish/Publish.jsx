import { Flex, Button, Heading, Separator, Text } from '@radix-ui/themes';
import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Datepicker from 'react-tailwindcss-datepicker';
import { apiCall } from '../../utils/Helper';
import Navbar from '../../components/Navbar/Navbar';
import { CheckIcon } from '@radix-ui/react-icons';

const Publish = () => {
  const token = localStorage.getItem('token');
  const email = localStorage.getItem('email');
  const { listingId } = useParams();
  const navigate = useNavigate();
  const [values, setValues] = useState([]);
  const [savedValues, setSavedValues] = useState([]);
  const [value, setValue] = useState(() => {
    const start = new Date();
    const end = new Date();
    end.setDate(start.getDate() + 1);
    return {
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
    };
  });
  const handleValueChange = (newValue) => {
    setValue(newValue);
  }
  if (!token || !email) {
    navigate('/login');
  }

  const handleDateRangeSave = () => {
    setValues([...values, value]);
    setSavedValues([...savedValues, {
      startDate: value.startDate,
      endDate: value.endDate,
    }]);
    setValue(() => {
      const start = new Date();
      const end = new Date();
      end.setDate(start.getDate() + 1);
      return {
        startDate: start.toISOString().split('T')[0],
        endDate: end.toISOString().split('T')[0],
      };
    });
  }

  const handleDeleteDateRange = (index) => {
    const updatedSavedValues = savedValues.filter((_, idx) => idx !== index);
    setSavedValues(updatedSavedValues);
    const changeValues = values.filter((_, idx) => idx !== index);
    setValues(changeValues);
  }

  const handleDateRangeSubmit = async () => {
    const dates = [];
    for (const value of values) {
      const startDate = new Date(value.startDate);
      const endDate = new Date(value.endDate);
      const diff = (endDate - startDate) / (1000 * 60 * 60 * 24);

      let start = 0;
      while (start < diff) {
        const newDate = new Date(startDate);
        newDate.setDate(newDate.getDate() + start);
        dates.push(newDate.toISOString().split('T')[0]);
        start++;
      }
    }

    const availability = [...new Set(dates)].sort();

    const data = await apiCall('/listings/publish/' + listingId, 'PUT', { availability }, token);
    if (data) {
      navigate('/hosted');
    }
  }
  return (
    <Flex className='flex-col px-4 py-4 sm:px-16 lg:px-24 xl:px-48'>
      <Navbar />
      <Separator className='mt-2' orientation='horizontal' size='auto' />
      <Heading className='text-xl flex py-4'> Listing Visible Time</Heading>
      {savedValues.map((value, idx) => (
        <Flex key={idx} className='flex my-1'>
          <Text key={idx} className='flex my-1 items-center text-base' ><CheckIcon className='mr-2' />Saved from {value.startDate} to {value.endDate}</Text>
          <Button onClick={() => handleDeleteDateRange(idx)} className='ml-4 w-14'>Delete</Button>
        </Flex>
      ))}
      <Flex className='items-center'>
        <Datepicker
          value={value}
          onChange={handleValueChange}
        />
        <Button onClick={handleDateRangeSave} className='ml-4'>Save</Button>
      </Flex>
      <Button onClick={handleDateRangeSubmit} className='mt-4'>Submit</Button>
    </Flex>
  )
}

export default Publish;
