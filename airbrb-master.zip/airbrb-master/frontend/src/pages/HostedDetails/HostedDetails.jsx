import React, { useEffect, useState } from 'react';
import { Flex, Button, Badge, Heading, Separator, Text } from '@radix-ui/themes';
import { useParams } from 'react-router-dom';
import { apiCall } from '../../utils/Helper';
import Navbar from '../../components/Navbar/Navbar';
import { DotFilledIcon } from '@radix-ui/react-icons';

const HostedDetails = () => {
  const { listingId } = useParams();
  const token = localStorage.getItem('token');
  const [listingDetails, setListingDetails] = useState({});
  const [bookings, setBookings] = useState([]);
  const [totalBookedDays, setTotalBookedDays] = useState(0);
  const [totalProfitInYear, setTotalProfitInYear] = useState(0);

  useEffect(async () => {
    const data = await apiCall('/listings/' + listingId, 'GET', null, token);
    if (data) {
      setListingDetails(data.listing);
      const ListingBookings = await apiCall('/bookings', 'GET', null, token);
      setBookings(ListingBookings.bookings.filter((booking) => booking.listingId === listingId));
      const currentYear = new Date().getFullYear();
      // get booking in this year by the user
      const thisYearBook = ListingBookings.bookings
        .filter(booking => booking.listingId === listingId)
        .filter(booking => {
          const startDate = new Date(booking.dateRange.startDate);
          const endDate = new Date(booking.dateRange.endDate);
          return startDate.getFullYear() === currentYear || endDate.getFullYear() === currentYear;
        });

      const acceptedBookings = thisYearBook.filter(booking => booking.status === 'accepted');

      const totalDays = acceptedBookings.reduce((total, booking) => {
        return total + getNumDaysBooked(booking.dateRange.startDate, booking.dateRange.endDate);
      }, 0);

      const totalProfitInYear = acceptedBookings.reduce((total, booking) => {
        return total + Number(booking.totalPrice);
      }, 0);
      setTotalProfitInYear(totalProfitInYear);
      setTotalBookedDays(totalDays);
    }
  }, []);

  const handleStatusUpdate = async (newStatus, bookingId) => {
    if (newStatus === 'accept') {
      await apiCall('/bookings/accept/' + bookingId, 'PUT', null, token);
    } else if (newStatus === 'decline') {
      await apiCall('/bookings/decline/' + bookingId, 'PUT', null, token);
    }
    const ListingBookings = await apiCall('/bookings', 'GET', null, token);
    setBookings(ListingBookings.bookings.filter((booking) => booking.listingId === listingId));
  }

  const getNumDays = (postedOn) => {
    const postedOnDate = new Date(postedOn);
    const currentDate = new Date();
    const diffTime = currentDate - postedOnDate;

    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  }

  const getNumDaysBooked = (startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return Math.floor((end - start) / (1000 * 60 * 60 * 24));
  }

  return (
    <Flex className='flex-col mx-auto px-4 sm:px-16 lg:px-24 xl:px-48'>
      <Navbar/>
      <Separator className='mt-2' orientation='horizontal' size='auto' />
      <Flex direction='column' className='wb-3'>
        <Heading className='mt-5'>Booking Requests:</Heading>
        <Flex className='flex-row mt-2 text-gray-500'>
          <DotFilledIcon className='mt-1'/> <Text>Total days has been booked in this Year: {totalBookedDays}</Text>
        </Flex>
        <Flex className='flex-row mt-2 text-gray-500'>
          <DotFilledIcon className='mt-1'/> <Text>Total profit in this Year: ${totalProfitInYear}</Text>
        </Flex>
        <Flex direction='column' className='mt-5 pr-2 pl-2 pb-3 border-dashed border-2 border-indigo-600 rounded-md'>
          <Flex className='flex-row mt-3 justify-between border-b pb-1 item-center'>
            <Flex className='font-semibold text-xl'>{listingDetails.title}</Flex>
            <Flex className='text-xl'> {`$ ${listingDetails.price} Per Night`}</Flex>
          </Flex>
          <Flex className='my-2'>The post has been online for {getNumDays(listingDetails.postedOn)} Day(s)</Flex>
          <Flex direction='column' className=' divide-y font-semibold'>
            {bookings.map((booking, idx) => (
              <Flex key={booking.id} className='justify-between my-2'>
                <Flex>
                  <Text as='span' className='font-semibold text-gray-500'>Reserved user: </Text> {booking.owner}
                  <Text as='span' className='font-semibold text-gray-500 pr-5'></Text>{booking.dateRange.startDate}
                  <Text as='span' className='font-semibold text-gray-500 pl-2 pr-2'> -</Text> {booking.dateRange.endDate}
                  <Text as='span' className='font-semibold text-gray-500 pl-5'> total price:</Text> {booking.totalPrice}
                </Flex>
                {booking.status === 'pending'
                  ? <Flex className='items-center'>
                      <Badge variant='soft'>
                        {booking.status}
                      </Badge>
                      <Button onClick={() => handleStatusUpdate('accept', booking.id)}>Accept</Button>
                      <Button color='red' onClick={() => handleStatusUpdate('decline', booking.id)}>Declien</Button>
                    </Flex>
                  : <Badge variant='solid'>
                      {booking.status}
                    </Badge>}
              </Flex>
            ))}
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  )
}

export default HostedDetails;
